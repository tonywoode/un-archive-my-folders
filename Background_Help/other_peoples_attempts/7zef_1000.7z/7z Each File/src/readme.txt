                                               7z Each file
                                            =================

What is it  ?
-------------------------
Compress files to 7z. Put each file to a separate archive.
Useful for emulation (compressing roms for Snes9x, Nestopia ...)


x86 and x64 folders ??
-------------------------
Both folders have got 7zef.exe which is x86 (AutoHotkey's Ahk2Exe).
But the x86 folder contains 7z's x86 binaries, and the x64 folder contains 7z's x64 binaries.
That's the only difference.

Since I don't have a IA64 processor, I can't give you the IA64 binaries.
You will have to manually download them:
http://www.7-zip.org/download.html


Multithreading ?
-------------------------
Well, I tried to do my best.
In the config file there is a threads option.
That's the number of processes that will be run at the same time.
Not sure if this will work with dual core procs since I don't have one.
You guys got to find a way to autohotkey 'Run', on different procs.
Thus, that's a TODO.


Linux ?
-------------------------
Program starts with Wine, compress the first file using 7z Windows binaries and hangs.

It hangs because it waits for 7z to end. And, it seems like it can't detect it.

I tried with exe=7z so it uses the linux 7z, but it fails to start.

Thus, that's a TODO.


Building ?
-------------------------
Use 'src/Make exe.exe'.
Select source (7zef.ahk), target (7zef.exe), and icon (1.ico).

You can edit 'AutoHotkeySC.bin' with RessourceHacker too.
It contains the program ressources.


================================================================================================

Feel free to edit this script ;)

                                                                          2007-2008 by RedShadow
